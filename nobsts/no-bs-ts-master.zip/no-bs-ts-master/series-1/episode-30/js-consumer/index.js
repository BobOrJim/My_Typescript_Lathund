const { introduceMyself } = require("mylib");

console.log(introduceMyself("Jack", "Herrington"));
