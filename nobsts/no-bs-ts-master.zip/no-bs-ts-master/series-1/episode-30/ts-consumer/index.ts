import { introduceMyself, borgName } from "mylib";

console.log(introduceMyself("LG", "Herrington"));
console.log(borgName());
