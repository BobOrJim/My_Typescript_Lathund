const { getName } = require("./functions");

console.log(getName());
console.log(getName({ first: "a", last: "b" }));
